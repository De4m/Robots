# Move: Tilt Right

hexy.LF.setFootY(75)
hexy.LM.setFootY(75)
hexy.LB.setFootY(75)

hexy.RF.setFootY(0)
hexy.RM.setFootY(-10)
hexy.RB.setFootY(0)