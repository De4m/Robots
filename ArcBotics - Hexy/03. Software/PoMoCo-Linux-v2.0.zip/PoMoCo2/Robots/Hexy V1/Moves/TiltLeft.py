# Move: Tilt Left

hexy.LF.setFootY(0)
hexy.LM.setFootY(-10)
hexy.LB.setFootY(0)

hexy.RF.setFootY(75)
hexy.RM.setFootY(75)
hexy.RB.setFootY(75)