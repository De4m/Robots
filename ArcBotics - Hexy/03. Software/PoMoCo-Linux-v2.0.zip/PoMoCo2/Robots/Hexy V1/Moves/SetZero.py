# Move: Set Zero

for servo in hexy.servos:
    servo.SetDeg(0)