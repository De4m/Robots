import time

# Move: Tilt Backward

hexy.LF.setFootY(floor)
hexy.LM.setFootY(floor/2)
hexy.LB.setFootY(floor/4)

hexy.RF.setFootY(floor)
hexy.RM.setFootY(floor/2)
hexy.RB.setFootY(floor/4)