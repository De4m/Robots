import time

# Move: Belly Flop

move('Set Zero')
time.sleep(2)

move('Get Up')
time.sleep(0.5)