import time

# Move: Tilt Forward

hexy.LF.setFootY(floor/4)
hexy.LM.setFootY(floor/2)
hexy.LB.setFootY(floor)

hexy.RF.setFootY(floor/4)
hexy.RM.setFootY(floor/2)
hexy.RB.setFootY(floor)
