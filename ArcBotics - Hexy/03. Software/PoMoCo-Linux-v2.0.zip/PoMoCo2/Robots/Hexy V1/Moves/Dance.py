import time

# Move: Dance

move('Tilt Left')
time.sleep(0.2)
move('Tilt None')
time.sleep(0.2)
move('Tilt Right')
time.sleep(0.2)
move('Tilt None')
time.sleep(0.2)

move('Tilt Left')
time.sleep(0.2)
move('Tilt None')
time.sleep(0.2)
move('Tilt Right')
time.sleep(0.2)
move('Tilt None')
time.sleep(0.2)

move('Tilt Forward')
time.sleep(0.2)
move('Tilt None')
time.sleep(0.2)
move('Tilt Backward')
time.sleep(0.2)
move('Tilt None')
time.sleep(0.2)

move('Tilt Forward')
time.sleep(0.2)
move('Tilt None')
time.sleep(0.2)
move('Tilt Backward')
time.sleep(0.2)
move('Tilt None')
time.sleep(0.2)